create view v_user as
select `bills`.`user`.`id`        AS `id`,
       `bills`.`user`.`username`  AS `username`,
       `bills`.`user`.`loginname` AS `loginname`,
       `bills`.`user`.`sex`       AS `sex`
from `bills`.`user`;

